#' A coolection of data management tools
#'
#' A collection of functions which might be helpful/useful for our
#' day-to-day ventures into data analysis at Environmentalinformatics
#' group, Department of Geography, Philipps University Marburg.
#'
#' @name DataMa
#' @aliases DataMa
#' @docType package
#' @title DataMa: magic functions for data management
#' @author Thomas Nauss
#' \emph{Maintainer:} Thomas Nauss \email{nausst@@gmail.com}
#'
#' @keywords package
#'
NULL